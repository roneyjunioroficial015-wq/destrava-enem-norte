# Destrava ENEM Norte - Projeto

Scaffold React + Vite que referencia imagens já enviadas no repositório. Coloque as imagens na pasta `public/` com os nomes mostrados (por exemplo `1762550891544.jpg`).

Para rodar:
1. npm install
2. npm run dev
