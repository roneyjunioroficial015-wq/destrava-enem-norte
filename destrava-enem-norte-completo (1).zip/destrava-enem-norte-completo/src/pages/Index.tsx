import React from 'react';
import Hero from '@/components/Hero';
import WhatIs from '@/components/WhatIs';
import ForWho from '@/components/ForWho';
import Modules from '@/components/Modules';
import Bonuses from '@/components/Bonuses';
import Pricing from '@/components/Pricing';
import WhyDifferent from '@/components/WhyDifferent';
import FinalCTA from '@/components/FinalCTA';

const Index = () => {
  return (
    <main>
      <Hero />
      <WhatIs />
      <ForWho />
      <Modules />
      <Bonuses />
      <Pricing />
      <WhyDifferent />
      <FinalCTA />
    </main>
  );
};

export default Index;
