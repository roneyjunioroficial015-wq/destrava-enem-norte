import React from 'react';
import Index from './pages/Index';

const App = () => {
  return <Index />;
};

export default App;
