import React from 'react';

const WhatIs = () => {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto text-center max-w-3xl">
        <h2 className="text-3xl font-bold">🚀 O que é o Destrava ENEM Norte?</h2>
        <p className="mt-4 text-lg text-slate-700">Curso prático, com aulas curtas e materiais focados no que realmente cai no ENEM.</p>
        <img src="/1762551026558.jpg" alt="Estudar" className="mx-auto mt-6 rounded-lg" />
      </div>
    </section>
  );
};

export default WhatIs;
