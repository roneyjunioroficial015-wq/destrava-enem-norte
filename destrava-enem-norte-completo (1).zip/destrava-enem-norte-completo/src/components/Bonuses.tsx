import React from 'react';

const Bonuses = () => {
  return (
    <section className="py-16 bg-gradient-to-br from-white to-slate-50">
      <div className="container mx-auto max-w-4xl text-center">
        <h2 className="text-3xl font-bold mb-6">🎁 Bônus</h2>
        <div className="grid md:grid-cols-3 gap-4">
          <div className="bg-white p-6 rounded shadow">
            <img src="/1762550943434.jpg" alt="eBook" className="mx-auto w-28 mb-4" />
            <h3 className="font-semibold">Mini eBook</h3>
            <p className="text-sm text-slate-600">Modelos de redação e resumos práticos.</p>
          </div>
          <div className="bg-white p-6 rounded shadow">
            <img src="/1762551083530.jpg" alt="approved" className="mx-auto w-28 mb-4" />
            <h3 className="font-semibold">Grupo VIP</h3>
            <p className="text-sm text-slate-600">Suporte e lives semanais.</p>
          </div>
          <div className="bg-white p-6 rounded shadow">
            <img src="/1762551090299.jpg" alt="icons" className="mx-auto w-28 mb-4" />
            <h3 className="font-semibold">Planilha</h3>
            <p className="text-sm text-slate-600">Cronograma pronto pra usar.</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Bonuses;
