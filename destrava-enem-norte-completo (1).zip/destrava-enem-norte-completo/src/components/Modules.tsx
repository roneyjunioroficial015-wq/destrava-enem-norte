import React from 'react';

const Modules = () => {
  const modules = [
    { title: 'Começo Inteligente', items: ['Rotina de estudos', 'Temas que mais caem'] },
    { title: 'Foco e Produtividade', items: ['Pomodoro Amazônico', 'Apps gratuitos'] },
    { title: 'Redação Nota 900', items: ['Estrutura 5 passos', 'Modelos prontos'] },
  ];
  return (
    <section className="py-16">
      <div className="container mx-auto">
        <h2 className="text-3xl font-bold text-center mb-6">🧩 Módulos</h2>
        <div className="grid md:grid-cols-3 gap-4">
          {modules.map((m,i)=>(
            <div key={i} className="p-4 bg-white rounded shadow">
              <h3 className="font-semibold">{m.title}</h3>
              <ul className="mt-2 text-sm">{m.items.map((it,xi)=>(<li key={xi}>• {it}</li>))}</ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Modules;
