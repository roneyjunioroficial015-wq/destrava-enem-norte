import React from 'react';
import Button from './ui/button';

const Pricing = () => {
  const paymentLink = "https://pay.kiwify.com.br/SB4sYeC";
  return (
    <section className="py-16">
      <div className="container mx-auto max-w-2xl">
        <div className="bg-white p-8 rounded-2xl shadow text-center">
          <img src="/1762551083530.jpg" alt="Aprovado" className="mx-auto w-48 mb-6 rounded-lg" />
          <h3 className="text-4xl font-extrabold text-sky-700 mb-2">R$29,90</h3>
          <p className="text-sm text-slate-600 mb-6">Pagamento único • Acesso vitalício</p>
          <a href={paymentLink} target="_blank" rel="noreferrer"><Button>GARANTIR MINHA VAGA AGORA</Button></a>
        </div>
      </div>
    </section>
  );
};

export default Pricing;
