import React from 'react';
import Button from './ui/button';

const FinalCTA = () => {
  const paymentLink = "https://pay.kiwify.com.br/SB4sYeC";
  return (
    <section className="py-16 bg-gradient-to-br from-sky-700 to-sky-500 text-white">
      <div className="container mx-auto text-center">
        <h2 className="text-3xl font-extrabold mb-4">🏁 Pronto pra começar?</h2>
        <p className="mb-6">Garanta sua vaga com preço promocional.</p>
        <a href={paymentLink} target="_blank" rel="noreferrer"><Button>QUERO COMEÇAR AGORA</Button></a>
      </div>
    </section>
  );
};

export default FinalCTA;
