import * as React from "react";

export const Button = ({ children, className = '', ...props }: any) => {
  return (
    <button className={'inline-flex items-center gap-2 px-6 py-3 rounded-md text-white bg-yellow-400 hover:bg-yellow-500 ' + className} {...props}>
      {children}
    </button>
  );
};

export default Button;
