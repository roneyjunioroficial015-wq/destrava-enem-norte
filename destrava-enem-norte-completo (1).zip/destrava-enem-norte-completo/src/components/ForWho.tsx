import React from 'react';

const ForWho = () => {
  const list = [
    'Quem quer passar no ENEM 2025',
    'Quem estuda com celular e internet fraca',
    'Quem mora no interior e quer mudar de vida',
  ];
  return (
    <section className="py-16 bg-slate-50">
      <div className="container mx-auto max-w-3xl">
        <h2 className="text-3xl font-bold text-center">🎯 Pra quem é o curso</h2>
        <div className="mt-6 grid gap-4">
          {list.map((l,i)=>(<div key={i} className="p-4 bg-white rounded shadow">{l}</div>))}
        </div>
        <img src="/1762551077124.jpg" alt="Student desk" className="mt-6 rounded-lg" />
      </div>
    </section>
  );
};

export default ForWho;
