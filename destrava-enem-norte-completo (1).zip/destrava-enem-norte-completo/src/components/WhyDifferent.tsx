import React from 'react';

const WhyDifferent = () => (
  <section className="py-16 bg-slate-50">
    <div className="container mx-auto max-w-4xl">
      <h2 className="text-3xl font-bold text-center mb-6">⚡ Por que esse curso é diferente</h2>
      <div className="grid md:grid-cols-2 gap-4">
        <div className="p-4 bg-white rounded shadow">
          <h3 className="font-semibold">Aulas curtas</h3>
          <p className="text-sm text-slate-600">Direto ao ponto, sem enrolação.</p>
        </div>
        <div className="p-4 bg-white rounded shadow">
          <h3 className="font-semibold">Otimizado pra celular</h3>
          <p className="text-sm text-slate-600">Roda bem mesmo com internet fraca.</p>
        </div>
      </div>
    </div>
  </section>
);

export default WhyDifferent;
