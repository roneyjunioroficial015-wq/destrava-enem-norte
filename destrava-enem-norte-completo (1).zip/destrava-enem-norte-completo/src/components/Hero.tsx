import React from 'react';
import Button from './ui/button';

const Hero = () => {
  const paymentLink = "https://pay.kiwify.com.br/SB4sYeC";
  return (
    <section className="bg-gradient-to-br from-sky-700 to-sky-500 text-white py-20">
      <div className="container mx-auto flex flex-col md:flex-row items-center gap-8">
        <div className="md:w-1/2">
          <h1 className="text-4xl md:text-5xl font-extrabold mb-4">🧠 Destrava ENEM Norte</h1>
          <p className="mb-6 text-lg">Estude do celular, com método prático e direto — feito pra você do Norte.</p>
          <a href={paymentLink} target="_blank" rel="noreferrer"><Button>💎 QUERO MEU ACESSO AGORA</Button></a>
        </div>
        <div className="md:w-1/2">
          <img src="/1762550891544.jpg" alt="Estudantes" className="w-full rounded-lg shadow-lg" />
        </div>
      </div>
    </section>
  );
};

export default Hero;
